package pepse.wold;

public class Avatar {
}
