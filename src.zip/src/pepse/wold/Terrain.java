package pepse.wold;

import danogl.GameObject;
import danogl.collisions.GameObjectCollection;
import danogl.collisions.Layer;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import danogl.util.Vector2;
import pepse.util.ColorSupplier;
import pepse.util.ConstantRandomSupplier;
import java.awt.*;
import java.util.ArrayDeque;
import java.util.ArrayList;


public class Terrain {
    private static final float SCREEN_PERCENTAGE_FOR_GROUND_HEIGHT_AT_0 = 0.7f;
    private static final int MAX_VARIATION_HEIGHT_FROM_0 = 10;
    private static final Color BASE_GROUND_COLOR = new Color(212, 123, 74);
    private final ArrayDeque<ArrayList<Block>> blockDeque;
    private final int maxBlockIndexToSee;
    private int groundHeightAtX0;
    private final GameObjectCollection gameObjects;
    private final int groundLayer;
    private final ConstantRandomSupplier heightSupplier;
    Vector2 windowDimensions;

    public Terrain(GameObjectCollection gameObjects, int groundLayer, Vector2 windowDimensions, int seed) {
        this.gameObjects = gameObjects;
        this.groundLayer = groundLayer;
        groundHeightAtX0 = (int)(windowDimensions.y() * SCREEN_PERCENTAGE_FOR_GROUND_HEIGHT_AT_0);
        groundHeightAtX0 = (groundHeightAtX0/Block.SIZE) * Block.SIZE;
        // make sure that the index is dividable by 30
        this.heightSupplier = new ConstantRandomSupplier(seed);
        this.windowDimensions = windowDimensions;
        this.blockDeque = new ArrayDeque<ArrayList<Block>>();
        this.maxBlockIndexToSee = (int)windowDimensions.y()/Block.SIZE + MAX_VARIATION_HEIGHT_FROM_0;
    }

    public float groundHeightAt(float x) {
        return groundHeightAtX0 +
                (float) Math.floor(heightSupplier.noise(x) * MAX_VARIATION_HEIGHT_FROM_0) * Block.SIZE;
    }

    public void createInRange(int minX, int maxX) {
        for (int col = minX; col <= maxX; col ++) {
            this.blockDeque.addLast(addTerrainCol(col, maxBlockIndexToSee));
        }
    }

    public void createInRangeBackwards(int minX, int maxX) {
        for (int col = maxX; col >= minX; col --) {
            this.blockDeque.addFirst(addTerrainCol(col, maxBlockIndexToSee));
        }
    }

    private ArrayList<Block> addTerrainCol(int col, int maxBlockIndexToSee) {
        int groundHeightAtCol = (int)(groundHeightAt(col))/Block.SIZE;
        ArrayList<Block> blocksInCol = new ArrayList<>();
        blocksInCol.add(addTerrainBlock(groundHeightAtCol, col, groundLayer));
        for (int row = groundHeightAtCol + 1; row <= maxBlockIndexToSee; row ++) {
            blocksInCol.add(addTerrainBlock(row, col, Layer.STATIC_OBJECTS));
        }
        return blocksInCol;
    }

    private Block addTerrainBlock(int row, int col, int layer) {
        Renderable blockRenderable =
                new RectangleRenderable(ColorSupplier.approximateColor(BASE_GROUND_COLOR));
        Block groundBlock = new Block(
                new Vector2(col*Block.SIZE, row*Block.SIZE),
                blockRenderable);
        groundBlock.setTag("ground");
        this.gameObjects.addGameObject(groundBlock, layer);
        return groundBlock;
    }

    public void removeFormTerrain(int numOfCol, boolean fromRight) {
        ArrayList<Block> blocksInCol;
        for (int i = 0; i < numOfCol; i ++){
            if (fromRight){
                blocksInCol = this.blockDeque.removeLast();
            } else {
                blocksInCol = this.blockDeque.removeFirst();
            }
            GameObject save = blocksInCol.get(0);
            boolean check = gameObjects.removeGameObject(save, groundLayer);
            for (GameObject gameObject: gameObjects){
                if (gameObject.equals(save)){
                    System.out.println(save);
                }
        }
            for (int j = 1; j < blocksInCol.size(); j++){
                gameObjects.removeGameObject(blocksInCol.get(j), Layer.STATIC_OBJECTS);
            }
        }
    }

    public double getSeed(){return heightSupplier.getSeed();}
}


