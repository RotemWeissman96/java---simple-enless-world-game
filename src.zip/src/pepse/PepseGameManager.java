package pepse;

import danogl.GameManager;
import danogl.GameObject;
import danogl.collisions.Layer;
import danogl.gui.ImageReader;
import danogl.gui.SoundReader;
import danogl.gui.UserInputListener;
import danogl.gui.WindowController;
import danogl.gui.rendering.Camera;
import danogl.gui.rendering.RectangleRenderable;
import danogl.gui.rendering.Renderable;
import pepse.wold.Avatar;
import pepse.wold.Block;
import pepse.wold.Sky;
import pepse.wold.Terrain;
import pepse.wold.bird.Bird;
import pepse.wold.daynight.Night;
import pepse.wold.daynight.Sun;
import danogl.util.Vector2;
import pepse.wold.daynight.SunHalo;
import pepse.wold.trees.Tree;
import java.awt.*;
import java.util.Random;

public class PepseGameManager extends GameManager {
    private static final float NIGHT_CYCLE = 20;
    private static final int SKY_AND_NIGHT_BACKGROUND = Layer.BACKGROUND;
    private static final int SUN_BACKGROUND = SKY_AND_NIGHT_BACKGROUND + 1;
    private static final int HALO_SUN_BACKGROUND = SUN_BACKGROUND + 1;
    private static final int TERRAIN_BACKGROUND = HALO_SUN_BACKGROUND + 20;
    private static final int TREE_BACKGROUND = TERRAIN_BACKGROUND + 20;
    private static final int AVATAR_SIZEX = 80;
    private static final int AVATAR_SIZEY = 100;
    private static final int SEEDS_RANDOM = 1000;
    private static final Color HALO_COLOR = new Color(255, 255, 0, 20);
    private Terrain terrain;
    private int maxIndexRendered;
    private int minIndexRendered;
    private Avatar avatar;
    private int windowDimensionBlocksX;

    public static void main(String[] args) {
        new PepseGameManager().run();
    }

    @Override
    public void initializeGame(ImageReader imageReader,
                               SoundReader soundReader,
                               UserInputListener inputListener,
                               WindowController windowController) {
        super.initializeGame(imageReader, soundReader, inputListener, windowController);

        // creating all the elements will need in creating the game objects
        Random rand = new Random();
        this.windowDimensionBlocksX = (int) (windowController.getWindowDimensions().x() / Block.SIZE);
        int seed = rand.nextInt(SEEDS_RANDOM);
        this.minIndexRendered = -(int) (windowDimensionBlocksX / 2);
        this.maxIndexRendered =
                (int) windowController.getWindowDimensions().x() / Block.SIZE - minIndexRendered;


        // we create the sky
        Sky.create(this.gameObjects(), windowController.getWindowDimensions(), SKY_AND_NIGHT_BACKGROUND);

        // this is where we add the terrain
        this.terrain = new Terrain(gameObjects(),
                TERRAIN_BACKGROUND,
                windowController.getWindowDimensions(),
                seed);
        terrain.createInRange(minIndexRendered, maxIndexRendered);

        // this is where we add the background for night and day
        Night.create(this.gameObjects(),
                SKY_AND_NIGHT_BACKGROUND,
                windowController.getWindowDimensions(),
                NIGHT_CYCLE);

        // this is where we add the sun to the window.
        GameObject sun = Sun.create(this.gameObjects(),
                SUN_BACKGROUND,
                windowController.getWindowDimensions(),
                NIGHT_CYCLE * 2);

        // this is where we add the sunHalo to the window.
        SunHalo.create(this.gameObjects(),
                HALO_SUN_BACKGROUND,
                sun,
                HALO_COLOR);

        // this is where we add the tree and the leaf.
        Tree tree = new Tree(this.gameObjects(),
                TREE_BACKGROUND,
                terrain::groundHeightAt);
        tree.createInRange(minIndexRendered, maxIndexRendered);

        // this function we use in order if the was not any tree created so
        // shouldn't bee ann error that the layer was not created
        checking_leaf_creation(windowController);
        gameObjects().layers().shouldLayersCollide(Layer.DEFAULT, TERRAIN_BACKGROUND, true);
        gameObjects().layers().shouldLayersCollide(Layer.DEFAULT, TREE_BACKGROUND, true);
        gameObjects().layers().shouldLayersCollide((TREE_BACKGROUND + 1),
                TERRAIN_BACKGROUND,
                true);

        // creating the avatar wo the window controller
        this.avatar = Avatar.create(gameObjects(),
                Layer.DEFAULT,
                new Vector2(AVATAR_SIZEX, AVATAR_SIZEY), inputListener,
                imageReader);
        this.setCamera(new Camera(avatar,
                Vector2.ZERO,
                windowController.getWindowDimensions(),
                windowController.getWindowDimensions()));

        // creating the bird for the window controller
        new Bird(imageReader,
                avatar,
                gameObjects(),
                windowController);
    }


    /**
     * created this function in case the tree layer was not created so I
     * added a layer that there shouldn't be an error
     */
    private void checking_leaf_creation(WindowController windowController) {
        Renderable blockRenderable =
                new RectangleRenderable(Color.BLACK);
        Block Block1 = new Block(
                new Vector2(windowController.getWindowDimensions().add(new Vector2(1000, 1000))),
                blockRenderable);
        Block1.setTag("extra layer");
        gameObjects().addGameObject(Block1, TREE_BACKGROUND + 1);
        Block Block2 = new Block(
                new Vector2(windowController.getWindowDimensions().add(new Vector2(1000, 1000))),
                blockRenderable);
        Block2.setTag("extra layer");
        gameObjects().addGameObject(Block2, TREE_BACKGROUND);
    }


    /**
     * to create the world from the left
     */
    void addingLeft() {
        if (avatar.getCenter().x() / Block.SIZE < minIndexRendered + windowDimensionBlocksX * 0.75) {
            System.out.println("adding terrain left");
            int numOfBlocks =  windowDimensionBlocksX / 4;
            terrain.createInRangeBackwards(minIndexRendered - numOfBlocks, minIndexRendered);
            terrain.removeFormTerrain(numOfBlocks, false);
            minIndexRendered -= numOfBlocks;
            maxIndexRendered =  (minIndexRendered + windowDimensionBlocksX);
        }
    }


    /**
     * to create the world from the right
     */
    void addingRight() {
        if (avatar.getCenter().x() / Block.SIZE > maxIndexRendered - windowDimensionBlocksX * 0.75) {
            int numOfBlocks =  windowDimensionBlocksX / 4;
            terrain.createInRange(maxIndexRendered, maxIndexRendered + numOfBlocks);
            terrain.removeFormTerrain(numOfBlocks, true);
            maxIndexRendered += numOfBlocks;
            minIndexRendered =  (maxIndexRendered - windowDimensionBlocksX);
            System.out.println("adding terrain right");
        }
    }

    /**
     * checking each moment where the avatar is
     */
    public void update(float deltaTime) {
        super.update(deltaTime);
        addingRight();
        addingLeft();
    }
}

